var assert = require('assert');
var huffman = require('../src/huffman');
var chai = require('chai');
var should = chai.should();

describe('huffman', function() {
    describe('#decode()', function() {
        it('should return new bits object.', function() {
            // TODO
        });
    });
});