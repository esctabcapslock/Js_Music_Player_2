var Mp3 = require('./src/decode')

module.exports = Mp3;
